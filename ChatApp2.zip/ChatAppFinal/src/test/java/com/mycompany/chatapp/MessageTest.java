package com.mycompany.chatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * MessageTest - JUnit 5 unit tests for the Message class.
 * Tests all methods specified in the PROG5121 Parts 2 and 3 POE requirements.
 *
 * Part 2 test data:
 *   Message 1: recipient = +27718693002, text = "Hi Mike, can you join us for dinner tonight?"
 *   Message 2: recipient = 08575975889 (invalid - no international code)
 *
 * Part 3 test data (five POE messages):
 *   Message 1: recipient = +27834557896  (flagged as Sent)
 *   Message 2: recipient = +27838884567  (flagged as Sent)
 *   Message 3: recipient = +27834484567
 *   Message 4: recipient = 0838884567    (flagged as Sent - invalid format but still processed)
 *   Message 5: recipient = +27838884567  (flagged as Sent)
 */
public class MessageTest {

    // --- Part 2 test objects ---
    private Message validMessage;
    private Message invalidRecipientMessage;

    // --- Part 3 test objects ---
    private Message part3Message1;
    private Message part3Message2;
    private Message part3Message3;
    private Message part3Message4;
    private Message part3Message5;

    /**
     * Sets up all test objects before each @Test method runs.
     * Uses exact test data from the POE for both Part 2 and Part 3.
     * The test constructor accepts a specific messageID so hashes are predictable.
     */
    @BeforeEach
    public void setUp() {
        // Clear all static session lists so tests do not interfere with each other
        Message.clearMessages();

        // --- Part 2 messages ---
        validMessage = new Message(
            "0000000000",
            0,
            "+27718693002",
            "Hi Mike, can you join us for dinner tonight?"
        );

        invalidRecipientMessage = new Message(
            "0000000001",
            1,
            "08575975889",
            "Hi Keegan, did you receive the payment?"
        );

        // --- Part 3 messages (POE test data) ---
        part3Message1 = new Message(
            "1000000001",
            1,
            "+27834557896",
            "Did you get the cake?"
        );

        part3Message2 = new Message(
            "1000000002",
            2,
            "+27838884567",
            "Where are you? You are late! I have asked you to be on time."
        );

        part3Message3 = new Message(
            "1000000003",
            3,
            "+27834484567",
            "Please call me when you arrive."
        );

        part3Message4 = new Message(
            "1000000004",
            4,
            "0838884567",
            "It is dinner time!"
        );

        part3Message5 = new Message(
            "1000000005",
            5,
            "+27838884567",
            "Ok, I am leaving without you."
        );
    }

    // ---------------------------------------------------------------
    // PART 2 - MESSAGE LENGTH TESTS
    // ---------------------------------------------------------------

    /**
     * Test: message text within the 250 character limit.
     * Expected return: "Message ready to send."
     */
    @Test
    public void testMessageLengthValid() {
        String result = validMessage.checkMessageLength(
            "Hi Mike, can you join us for dinner tonight?"
        );
        assertEquals("Message ready to send.", result);
    }

    /**
     * Test: message text that exceeds the 250 character limit.
     * Expected return: failure message with exact characters over the limit.
     */
    @Test
    public void testMessageLengthInvalid() {
        String longMessage = "This message is intentionally too long. "
            + "It has been constructed to exceed the two hundred and fifty "
            + "character limit that is enforced by the checkMessageLength method "
            + "inside the Message class. Extra text added here to push it over.";

        int expectedOver = longMessage.length() - 250;
        String expectedResult = "Message exceeds 250 characters by " + expectedOver + "; please reduce the size.";

        String result = validMessage.checkMessageLength(longMessage);
        assertEquals(expectedResult, result);
    }

    // ---------------------------------------------------------------
    // PART 2 - RECIPIENT CELL NUMBER TESTS
    // ---------------------------------------------------------------

    /**
     * Test: correctly formatted recipient number.
     * Expected return: "Cell phone number successfully captured."
     */
    @Test
    public void testRecipientCellValid() {
        String result = validMessage.checkRecipientCell();
        assertEquals("Cell phone number successfully captured.", result);
    }

    /**
     * Test: incorrectly formatted recipient number (no international code).
     * Expected return: the detailed failure message.
     */
    @Test
    public void testRecipientCellInvalid() {
        String result = invalidRecipientMessage.checkRecipientCell();
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // ---------------------------------------------------------------
    // PART 2 - MESSAGE HASH TEST
    // ---------------------------------------------------------------

    /**
     * Test: hash generated correctly using the POE's exact test data.
     * ID "0000000000" -> first 2 chars = "00", number = 0,
     * first word = "Hi", last word = "tonight" -> expected: "00:0:HITONIGHT"
     */
    @Test
    public void testMessageHashCorrect() {
        assertEquals("00:0:HITONIGHT", validMessage.getMessageHash());
    }

    // ---------------------------------------------------------------
    // PART 2 - MESSAGE ID TESTS
    // ---------------------------------------------------------------

    /**
     * Test: checkMessageID() returns true for a valid 10-character ID.
     */
    @Test
    public void testMessageIDCreated() {
        assertTrue(validMessage.checkMessageID(), "Message ID should be 10 characters or fewer");
    }

    /**
     * Test: message ID is exactly 10 characters long.
     */
    @Test
    public void testMessageIDLength() {
        assertEquals(10, validMessage.getMessageID().length());
    }

    // ---------------------------------------------------------------
    // PART 2 - SENT MESSAGE ACTION TESTS
    // ---------------------------------------------------------------

    /**
     * Test: user selects option 1 (Send Message).
     * Expected return: "Message successfully sent."
     */
    @Test
    public void testSentMessageSend() {
        String result = validMessage.sentMessage(1);
        assertEquals("Message successfully sent.", result);
    }

    /**
     * Test: user selects option 2 (Disregard Message).
     * Expected return: "Press 0 to delete the message."
     */
    @Test
    public void testSentMessageDisregard() {
        String result = validMessage.sentMessage(2);
        assertEquals("Press 0 to delete the message.", result);
    }

    /**
     * Test: user selects option 3 (Store Message).
     * Expected return: "Message successfully stored."
     */
    @Test
    public void testSentMessageStore() {
        String result = validMessage.sentMessage(3);
        assertEquals("Message successfully stored.", result);
    }

    // ---------------------------------------------------------------
    // PART 3 - UNIT TESTS
    // ---------------------------------------------------------------

    /**
     * Test: sentMessages array correctly populated when messages flagged as Sent.
     * Messages 1 and 4 are sent. Array must contain both their text values.
     * POE expected: "Did you get the cake?" and "It is dinner time!"
     */
    @Test
    public void testSentMessagesArray_correctlyPopulated() {
        part3Message1.sentMessage(1);
        part3Message4.sentMessage(1);

        String report = Message.printMessages();
        assertTrue(report.contains("Did you get the cake?"),
            "Sent array should contain message 1 text");
        assertTrue(report.contains("It is dinner time!"),
            "Sent array should contain message 4 text");
    }

    /**
     * Test: displayLongestMessage() returns the correct message from the stored array.
     * POE expected: "Where are you? You are late! I have asked you to be on time."
     */
    @Test
    public void testDisplayLongestMessage_returnsCorrectMessage() {
        Message.addToStoredMessages("Did you get the cake?");
        Message.addToStoredMessages("Where are you? You are late! I have asked you to be on time.");
        Message.addToStoredMessages("Please call me when you arrive.");
        Message.addToStoredMessages("It is dinner time!");
        Message.addToStoredMessages("Ok, I am leaving without you.");

        String result = Message.displayLongestMessage();
        assertEquals("Where are you? You are late! I have asked you to be on time.", result);
    }

    /**
     * Test: searchByMessageID() returns the correct message for a given ID.
     * Message 4 has ID "1000000004". POE expected: "It is dinner time!"
     */
    @Test
    public void testSearchByMessageID_returnsCorrectMessage() {
        part3Message1.sentMessage(1);
        part3Message4.sentMessage(1);

        String result = Message.searchByMessageID("1000000004");
        assertEquals("It is dinner time!", result);
    }

    /**
     * Test: searchByRecipient() returns all messages for a given recipient.
     * +27838884567 is the recipient of messages 2 and 5.
     * POE expected: both messages returned.
     */
    @Test
    public void testSearchByRecipient_returnsAllMatchingMessages() {
        part3Message1.sentMessage(1);
        part3Message2.sentMessage(1);
        part3Message3.sentMessage(1);
        part3Message4.sentMessage(1);
        part3Message5.sentMessage(1);

        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."),
            "Result should contain message 2");
        assertTrue(result.contains("Ok, I am leaving without you."),
            "Result should contain message 5");
    }

    /**
     * Test: deleteByHash() removes the correct message and returns the success message.
     * Deleting message 2 by its hash.
     * POE expected: "Message: [text] successfully deleted."
     */
    @Test
    public void testDeleteByHash_removesCorrectMessage() {
        part3Message2.sentMessage(1);

        String hashToDelete = part3Message2.getMessageHash();

        String result = Message.deleteByHash(hashToDelete);
        assertEquals(
            "Message: Where are you? You are late! I have asked you to be on time. successfully deleted.",
            result
        );
    }

    /**
     * Test: printMessages() report contains hash, recipient, and message for all sent messages.
     */
    @Test
    public void testDisplayReport_containsRequiredFields() {
        part3Message1.sentMessage(1);
        part3Message2.sentMessage(1);

        String report = Message.printMessages();

        assertTrue(report.contains(part3Message1.getMessageHash()),
            "Report should contain hash for message 1");
        assertTrue(report.contains("+27834557896"),
            "Report should contain recipient for message 1");
        assertTrue(report.contains("Did you get the cake?"),
            "Report should contain text for message 1");

        assertTrue(report.contains(part3Message2.getMessageHash()),
            "Report should contain hash for message 2");
        assertTrue(report.contains("+27838884567"),
            "Report should contain recipient for message 2");
        assertTrue(report.contains("Where are you? You are late! I have asked you to be on time."),
            "Report should contain text for message 2");
    }
}
