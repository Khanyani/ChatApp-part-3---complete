package com.mycompany.chatapp;

// Attribution: org.json library used for JSON file storage and reading
// Source: https://mvnrepository.com/artifact/org.json/json
// Version used: 20231013

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;


/**
 * Message class - represents a single chat message in ChatApp.
 * Handles message creation, validation, hashing, JSON storage, and session tracking.
 * Part of the PROG5121 POE - updated in Part 3 to include parallel arrays and search features.
 */
public class Message {

    // --- Instance Fields ---
    private String messageID;       // 10-digit randomly generated ID
    private int messageNumber;      // position in the send loop
    private String recipient;       // validated international cell number
    private String messageText;     // max 250 characters
    private String messageHash;     // auto-generated from ID, number, and message words
    private String sendStatus;      // Sent, Stored, or Disregarded

    // ---------------------------------------------------------------
    // PART 3 - PARALLEL STATIC ARRAYS
    // All lists are static so they persist across every Message object
    // created during the session and can be accessed without an instance.
    //
    // Two groups:
    //   "All processed" group (sent + stored, aligned with each other):
    //       messageIDs, messageHashes, recipientList, allMessageTexts
    //   "Sent only" group (used for the report and delete, aligned with each other):
    //       sentMessages, sentHashes, sentRecipients
    //   "Other" lists:
    //       disregardedMessages, storedMessages
    // ---------------------------------------------------------------

    /** Text of every message the user chose to Send - used for the report */
    private static ArrayList<String> sentMessages    = new ArrayList<>();

    /** Hash of every sent message - parallel to sentMessages */
    private static ArrayList<String> sentHashes      = new ArrayList<>();

    /** Recipient of every sent message - parallel to sentMessages */
    private static ArrayList<String> sentRecipients  = new ArrayList<>();

    /** Text of every message the user chose to Discard */
    private static ArrayList<String> disregardedMessages = new ArrayList<>();

    /** Text of messages read back from the JSON file at startup */
    private static ArrayList<String> storedMessages  = new ArrayList<>();

    /** Count of messages stored to JSON this session (for returnTotalMessages) */
    private static int storedThisSession = 0;

    // --- "All processed" group: covers both sent and stored, aligned by index ---

    /** Hash for every processed message (sent or stored) */
    private static ArrayList<String> messageHashes   = new ArrayList<>();

    /** ID for every processed message (sent or stored) */
    private static ArrayList<String> messageIDs      = new ArrayList<>();

    /** Recipient for every processed message (sent or stored) */
    private static ArrayList<String> recipientList   = new ArrayList<>();

    /** Text for every processed message (sent or stored) - index matches messageIDs */
    private static ArrayList<String> allMessageTexts = new ArrayList<>();

    // ---------------------------------------------------------------
    // CONSTRUCTORS
    // ---------------------------------------------------------------

    /**
     * Runtime constructor - auto-generates the message ID and hash.
     * Used by MainApp when a user composes a message.
     *
     * @param messageNumber the position of this message in the send loop
     * @param recipient     the recipient's cell number
     * @param messageText   the message content (max 250 characters)
     */
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageID     = generateMessageID();
        this.messageHash   = createMessageHash();
    }

    /**
     * Test constructor - accepts a specific message ID so unit tests can predict the hash.
     * Used by MessageTest.java to pass known values.
     *
     * @param messageID     a specific 10-character ID for controlled testing
     * @param messageNumber the position of this message in the send loop
     * @param recipient     the recipient's cell number
     * @param messageText   the message content (max 250 characters)
     */
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID     = messageID;
        this.messageNumber = messageNumber;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageHash   = createMessageHash();
    }

    // ---------------------------------------------------------------
    // PRIVATE HELPERS
    // ---------------------------------------------------------------

    /**
     * Generates a random 10-digit message ID using Java's Random class.
     * Ensures the result is always exactly 10 digits.
     *
     * @return a String of exactly 10 digits
     */
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // ---------------------------------------------------------------
    // VALIDATION METHODS
    // ---------------------------------------------------------------

    /**
     * Checks that the message ID does not exceed 10 characters.
     *
     * @return true if the ID is 10 characters or fewer, false otherwise
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /**
     * Validates the message text length against the 250 character limit.
     *
     * @param message the message text entered by the user
     * @return "Message ready to send." on success, or a failure message with the overcount
     */
    public String checkMessageLength(String message) {
        if (message.length() > 250) {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    /**
     * Validates the recipient cell number stored in this message.
     * Must start with +27 and be exactly 12 characters.
     *
     * @return "Cell phone number successfully captured." on success,
     *         or a detailed failure message on invalid format
     */
    public String checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+27") && recipient.length() == 12) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // ---------------------------------------------------------------
    // HASH METHOD
    // ---------------------------------------------------------------

    /**
     * Builds the message hash from the first 2 chars of the ID, the message number,
     * and the first and last words of the message text.
     * Format: XX:N:FIRSTWORDLASTWORD (all uppercase)
     *
     * @return the generated hash string in uppercase
     */
    public String createMessageHash() {
        String idPart    = messageID.substring(0, 2);
        String[] words   = messageText.split(" ");
        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        return (idPart + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // ---------------------------------------------------------------
    // SEND / DISREGARD / STORE
    // ---------------------------------------------------------------

    /**
     * Handles the user's decision to Send, Disregard, or Store the message.
     * Populates the correct parallel arrays depending on the choice made.
     *
     * @param option 1 = Send, 2 = Disregard, 3 = Store
     * @return a String describing the action taken
     */
    public String sentMessage(int option) {
        switch (option) {

            case 1:
                // Send: populate both the "sent only" group and the "all processed" group
                sendStatus = "Sent";
                sentMessages.add(this.messageText);
                sentHashes.add(this.messageHash);
                sentRecipients.add(this.recipient);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                recipientList.add(this.recipient);
                allMessageTexts.add(this.messageText);
                return "Message successfully sent.";

            case 2:
                // Disregard: only record in the disregarded list - not tracked further
                sendStatus = "Disregarded";
                disregardedMessages.add(this.messageText);
                return "Press 0 to delete the message.";

            case 3:
                // Store: write to JSON, populate "all processed" group only (not sent lists)
                sendStatus = "Stored";
                storedThisSession++;
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                recipientList.add(this.recipient);
                allMessageTexts.add(this.messageText);
                storeMessage();
                return "Message successfully stored.";

            default:
                return "Invalid option selected. Message not processed.";
        }
    }

    // ---------------------------------------------------------------
    // PART 3 - JSON READ METHOD
    // ---------------------------------------------------------------

    /**
     * Reads messages.json line by line and loads each stored message into
     * the storedMessages array. Called once at startup after login.
     * Handles a missing file gracefully without crashing.
     * Attribution: org.json library - https://mvnrepository.com/artifact/org.json/json
     */
    public static void loadStoredMessages() {
        try (BufferedReader reader = new BufferedReader(new FileReader("messages.json"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    JSONObject obj = new JSONObject(line);
                    String text = obj.optString("message", "");
                    if (!text.isEmpty()) {
                        storedMessages.add(text);
                    }
                }
            }
        } catch (IOException e) {
            // File does not exist yet - expected on first run
            System.out.println("No previous messages found. Starting fresh session.");
        }
    }

    // ---------------------------------------------------------------
    // PART 3 - SEARCH AND DISPLAY METHODS
    // ---------------------------------------------------------------

    /**
     * Searches the storedMessages array and returns the message with the most characters.
     *
     * @return the longest message String, or a notice if no stored messages are loaded
     */
    public static String displayLongestMessage() {
        if (storedMessages.isEmpty()) {
            return "No stored messages available.";
        }
        String longest = "";
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    /**
     * Searches messageIDs for a matching ID and returns the corresponding message text
     * from allMessageTexts at the same index.
     * allMessageTexts covers both sent and stored messages so the index is always valid.
     *
     * @param id the message ID to search for
     * @return the matching message text, or "Message not found." if no match exists
     */
    public static String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return allMessageTexts.get(i);
            }
        }
        return "Message not found.";
    }

    /**
     * Searches recipientList for all messages sent to the given recipient.
     * Returns every matching message because there may be more than one.
     * Uses allMessageTexts so stored messages are found as well as sent ones.
     *
     * @param recipient the recipient cell number to search for
     * @return all matching messages as a newline-separated String, or a not-found notice
     */
    public static String searchByRecipient(String recipient) {
        StringBuilder results = new StringBuilder();
        for (int i = 0; i < recipientList.size(); i++) {
            if (recipientList.get(i).equals(recipient)) {
                results.append(allMessageTexts.get(i)).append("\n");
            }
        }
        if (results.length() == 0) {
            return "No messages found for recipient: " + recipient;
        }
        return results.toString().trim();
    }

    /**
     * Finds a message by its hash and removes it from all parallel arrays.
     * Uses messageHashes (the "all processed" group) to find the index, then
     * removes from both the "all processed" group and the "sent only" group
     * if the deleted entry was a sent message.
     *
     * @param hash the message hash to search for and delete
     * @return a success message with the deleted text, or "Hash not found." if no match
     */
    public static String deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String deletedText = allMessageTexts.get(i);

                // Remove from the "all processed" group
                messageHashes.remove(i);
                messageIDs.remove(i);
                recipientList.remove(i);
                allMessageTexts.remove(i);

                // If the same hash exists in the "sent only" group, remove it there too
                int sentIndex = sentHashes.indexOf(hash);
                if (sentIndex >= 0) {
                    sentMessages.remove(sentIndex);
                    sentHashes.remove(sentIndex);
                    sentRecipients.remove(sentIndex);
                }

                return "Message: " + deletedText + " successfully deleted.";
            }
        }
        return "Hash not found.";
    }

    // ---------------------------------------------------------------
    // DISPLAY AND COUNT METHODS
    // ---------------------------------------------------------------

    /**
     * Returns a formatted report of all sent messages including hash, recipient, and text.
     * Uses the "sent only" parallel lists so indices are always aligned.
     *
     * @return a formatted String report, or a notice if no messages have been sent
     */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder report = new StringBuilder();
        report.append("=== Message Report ===\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            report.append("Message Hash: ").append(sentHashes.get(i)).append("\n");
            report.append("Recipient:    ").append(sentRecipients.get(i)).append("\n");
            report.append("Message:      ").append(sentMessages.get(i)).append("\n");
            report.append("------------------------------\n");
        }
        return report.toString();
    }

    /**
     * Returns the total number of messages sent or stored during the session.
     * Disregarded messages are not counted.
     *
     * @return the integer count of sent and stored messages
     */
    public static int returnTotalMessages() {
        return sentMessages.size() + storedThisSession;
    }

    /**
     * Returns all messages loaded from the JSON file, formatted for display.
     *
     * @return a formatted String of stored messages, or a notice if none are loaded
     */
    public static String displayStoredMessages() {
        if (storedMessages.isEmpty()) {
            return "No stored messages found.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("=== Stored Messages ===\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            sb.append((i + 1)).append(". ").append(storedMessages.get(i)).append("\n");
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------
    // JSON STORAGE
    // ---------------------------------------------------------------

    /**
     * Saves this message to messages.json using the org.json library.
     * Appends each stored message as a new JSON line in the file.
     * Attribution: org.json library - https://mvnrepository.com/artifact/org.json/json
     */
    public void storeMessage() {
        JSONObject obj = new JSONObject();
        obj.put("messageID",     this.messageID);
        obj.put("messageNumber", this.messageNumber);
        obj.put("recipient",     this.recipient);
        obj.put("message",       this.messageText);
        obj.put("messageHash",   this.messageHash);
        obj.put("status",        this.sendStatus);

        try (FileWriter fw = new FileWriter("messages.json", true)) {
            fw.write(obj.toString() + "\n");
            System.out.println("Message saved to messages.json.");
        } catch (IOException e) {
            System.out.println("Error saving message: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------
    // GETTERS
    // ---------------------------------------------------------------

    /** @return the 10-digit message ID */
    public String getMessageID()   { return messageID; }

    /** @return the message number (loop position) */
    public int getMessageNumber()  { return messageNumber; }

    /** @return the recipient cell number */
    public String getRecipient()   { return recipient; }

    /** @return the message text */
    public String getMessageText() { return messageText; }

    /** @return the generated message hash */
    public String getMessageHash() { return messageHash; }

    /** @return the send status (Sent, Stored, or Disregarded) */
    public String getSendStatus()  { return sendStatus; }

    // ---------------------------------------------------------------
    // TEST HELPERS
    // ---------------------------------------------------------------

    /**
     * Clears all static session lists and resets the stored-this-session counter.
     * Used in unit tests to reset state between test cases.
     */
    public static void clearMessages() {
        sentMessages.clear();
        sentHashes.clear();
        sentRecipients.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        storedThisSession = 0;
        messageHashes.clear();
        messageIDs.clear();
        recipientList.clear();
        allMessageTexts.clear();
    }

    /**
     * Directly adds a message to the storedMessages list.
     * Used in unit tests to populate storedMessages without reading from a file.
     *
     * @param message the message text to add
     */
    public static void addToStoredMessages(String message) {
        storedMessages.add(message);
    }
}