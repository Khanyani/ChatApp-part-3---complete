package com.mycompany.chatapp;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * MainApp - entry point for the ChatApp console application.
 * Handles user registration, login, and the main messaging menu.
 * Parts 1, 2, and 3 of the PROG5121 POE all run through this class.
 */
public class MainApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // ---------------------------------------------------------------
        // REGISTRATION SECTION
        // ---------------------------------------------------------------
        System.out.println("=== USER REGISTRATION ===");

        boolean isRegistered = false;

        while (!isRegistered) {

            System.out.print("Enter a username: ");
            String username = input.nextLine();

            System.out.print("Enter a password: ");
            String password = input.nextLine();

            System.out.print("Enter your South African phone number (+27...): ");
            String phone = input.nextLine();

            String response = login.registerUser(username, password, phone);

            if (response.equals("User registered successfully.")) {
                System.out.println("\n" + response);
                isRegistered = true;
            } else {
                System.out.println("\nRegistration failed: " + response);
                System.out.println("Please try again.\n");
            }
        }

        // ---------------------------------------------------------------
        // LOGIN SECTION
        // ---------------------------------------------------------------
        System.out.println("\n=== USER LOGIN ===");

        boolean isLoggedIn = false;
        int attempts    = 0;
        int maxAttempts = 3;

        while (!isLoggedIn && attempts < maxAttempts) {

            attempts++;

            System.out.print("Enter your username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter your password: ");
            String loginPassword = input.nextLine();

            boolean loggedIn     = login.loginUser(loginUsername, loginPassword);
            String  loginMessage = login.returnLoginStatus(loggedIn);

            if (loggedIn) {
                System.out.println("\n" + loginMessage);
                isLoggedIn = true;
            } else {
                int remaining = maxAttempts - attempts;
                if (remaining > 0) {
                    System.out.println("\n" + loginMessage);
                    System.out.println("You have " + remaining + " attempt(s) remaining.\n");
                } else {
                    System.out.println("\nToo many failed attempts. Your account has been locked.");
                    System.out.println("Please contact support for assistance.");
                }
            }
        }

        // ---------------------------------------------------------------
        // PART 3: LOAD STORED MESSAGES AFTER SUCCESSFUL LOGIN
        // ---------------------------------------------------------------
        if (isLoggedIn) {
            Message.loadStoredMessages();
        }

        // ---------------------------------------------------------------
        // MAIN APPLICATION LOOP
        // ---------------------------------------------------------------
        if (isLoggedIn) {

            System.out.println("\nWelcome to ChatApp.");

            boolean running = true;

            while (running) {

                System.out.println("\n==============================");
                System.out.println("       CHATAPP MENU");
                System.out.println("==============================");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.println("4) Stored Messages");
                System.out.print("Enter your choice: ");

                int choice = readInt(input);

                switch (choice) {

                    case 1:
                        sendMessagesFlow(input);
                        break;

                    case 2:
                        System.out.println(Message.printMessages());
                        break;

                    case 3:
                        running = false;
                        System.out.println("Thank you for using ChatApp. Goodbye!");
                        break;

                    case 4:
                        storedMessagesMenu(input);
                        break;

                    default:
                        System.out.println("Invalid option. Please enter 1, 2, 3, or 4.");
                }
            }

        } else {
            System.out.println("\nAccess denied. Exiting ChatApp.");
        }

        input.close();
    }

    // ---------------------------------------------------------------
    // SEND MESSAGES FLOW
    // ---------------------------------------------------------------

    /**
     * Handles the full send-messages flow: prompts for how many messages,
     * then loops through each one collecting, validating, and processing
     * recipient and message text.
     *
     * @param input the shared Scanner
     */
    private static void sendMessagesFlow(Scanner input) {

        System.out.print("\nHow many messages would you like to send? ");
        int numMessages = readInt(input);

        if (numMessages <= 0) {
            System.out.println("Number of messages must be greater than 0.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {

            int messageNumber = i + 1;
            System.out.println("\n--- Message " + messageNumber + " ---");

            // Collect and validate recipient
            String  recipient      = "";
            boolean validRecipient = false;

            while (!validRecipient) {
                System.out.print("Enter recipient cell number (+27...): ");
                recipient = input.nextLine();

                Message tempMsg       = new Message("0000000000", messageNumber, recipient, "placeholder");
                String  recipientCheck = tempMsg.checkRecipientCell();
                System.out.println(recipientCheck);

                if (recipientCheck.equals("Cell phone number successfully captured.")) {
                    validRecipient = true;
                }
            }

            // Collect and validate message text
            String  messageText  = "";
            boolean validMessage = false;

            while (!validMessage) {
                System.out.print("Enter your message (max 250 characters): ");
                messageText = input.nextLine();

                Message tempMsg     = new Message("0000000000", messageNumber, recipient, messageText);
                String  lengthCheck = tempMsg.checkMessageLength(messageText);
                System.out.println(lengthCheck);

                if (lengthCheck.equals("Message ready to send.")) {
                    validMessage = true;
                }
            }

            // Create real message with generated ID
            Message message = new Message(messageNumber, recipient, messageText);

            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Enter your choice: ");

            int    sendOption = readInt(input);
            String sendResult = message.sentMessage(sendOption);
            System.out.println("\n" + sendResult);

            if (sendOption == 1 || sendOption == 3) {
                System.out.println("\nMessage Details:");
                System.out.println("Message ID:   " + message.getMessageID());
                System.out.println("Message Hash: " + message.getMessageHash());
                System.out.println("Recipient:    " + message.getRecipient());
                System.out.println("Message:      " + message.getMessageText());
            }
        }

        System.out.println("\nTotal messages sent/stored this session: " + Message.returnTotalMessages());
    }

    // ---------------------------------------------------------------
    // STORED MESSAGES SUB-MENU
    // ---------------------------------------------------------------

    /**
     * Displays and handles the Stored Messages sub-menu (option 4).
     * Six features: display all, longest message, search by ID,
     * search by recipient, delete by hash, and full report.
     *
     * @param input the shared Scanner
     */
    private static void storedMessagesMenu(Scanner input) {

        boolean inSubMenu = true;

        while (inSubMenu) {

            System.out.println("\n==============================");
            System.out.println("    STORED MESSAGES MENU");
            System.out.println("==============================");
            System.out.println("a) Display all stored messages");
            System.out.println("b) Display longest message");
            System.out.println("c) Search by message ID");
            System.out.println("d) Search by recipient");
            System.out.println("e) Delete message by hash");
            System.out.println("f) Display full report");
            System.out.println("q) Return to main menu");
            System.out.print("Enter your choice: ");

            String subChoice = input.nextLine().trim().toLowerCase();

            switch (subChoice) {

                case "a":
                    System.out.println("\n" + Message.displayStoredMessages());
                    break;

                case "b":
                    System.out.println("\nLongest message:");
                    System.out.println(Message.displayLongestMessage());
                    break;

                case "c":
                    System.out.print("\nEnter message ID to search: ");
                    String searchID = input.nextLine().trim();
                    System.out.println(Message.searchByMessageID(searchID));
                    break;

                case "d":
                    System.out.print("\nEnter recipient number to search: ");
                    String searchRecipient = input.nextLine().trim();
                    System.out.println(Message.searchByRecipient(searchRecipient));
                    break;

                case "e":
                    System.out.print("\nEnter message hash to delete: ");
                    String deleteHash = input.nextLine().trim();
                    System.out.println(Message.deleteByHash(deleteHash));
                    break;

                case "f":
                    System.out.println("\n" + Message.printMessages());
                    break;

                case "q":
                    inSubMenu = false;
                    break;

                default:
                    System.out.println("Invalid option. Please enter a, b, c, d, e, f, or q.");
            }
        }
    }

    // ---------------------------------------------------------------
    // INPUT HELPER
    // ---------------------------------------------------------------

    /**
     * Reads an integer from the scanner safely.
     * Returns -1 (triggering the default case) instead of crashing
     * if the user enters a non-integer value.
     *
     * @param input the shared Scanner
     * @return the integer entered, or -1 on invalid input
     */
    private static int readInt(Scanner input) {
        try {
            int value = input.nextInt();
            input.nextLine(); // consume the leftover newline
            return value;
        } catch (InputMismatchException e) {
            input.nextLine(); // clear the bad token
            return -1;
        }
    }
}
